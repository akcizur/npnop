import json, math, struct, random, os, sys
import numpy as np
import trimesh
from collections import OrderedDict

random.seed(5110)
OUT=sys.argv[1] if len(sys.argv)>1 else '/mnt/data/warrior_hooded_remastered.glb'
os.makedirs(os.path.dirname(OUT) or '.',exist_ok=True)

# Named material palette: subdued cinematic charcoal, weathered olive and ash-grey.
MATERIALS=OrderedDict([
 ('cloth',        {'name':'Tattered black robe','color':[16,18,18,255],'roughness':0.96,'metallic':0.0}),
 ('clothFold',    {'name':'Robe folds','color':[27,29,28,255],'roughness':0.94,'metallic':0.0}),
 ('pants',        {'name':'Layered dark trousers','color':[12,13,13,255],'roughness':0.97,'metallic':0.0}),
 ('skin',         {'name':'Weathered skin','color':[126,108,87,255],'roughness':0.88,'metallic':0.0}),
 ('skinHi',       {'name':'Skin highlights','color':[153,131,105,255],'roughness':0.86,'metallic':0.0}),
 ('skinShadow',   {'name':'Facial shadows','color':[65,51,40,255],'roughness':0.9,'metallic':0.0}),
 ('beard',        {'name':'Ash grey beard','color':[153,157,145,255],'roughness':0.94,'metallic':0.0}),
 ('beardHi',      {'name':'Beard silver strands','color':[181,182,167,255],'roughness':0.91,'metallic':0.0}),
 ('wrap',         {'name':'Olive linen wraps','color':[66,68,54,255],'roughness':0.98,'metallic':0.0}),
 ('leather',      {'name':'Weathered leather','color':[55,48,36,255],'roughness':0.96,'metallic':0.0}),
 ('metal',        {'name':'Oxidized antique metal','color':[112,103,75,255],'roughness':0.72,'metallic':0.38}),
 ('eye',          {'name':'Eyes and deep seams','color':[31,27,23,255],'roughness':0.66,'metallic':0.0}),
 ('boot',         {'name':'Black worn boots','color':[19,19,17,255],'roughness':0.95,'metallic':0.0}),
])

BONES=OrderedDict([
 ('hips',       {'parent':None,       'pos':(0.0,0.88,0.0)}),
 ('spine',      {'parent':'hips',     'pos':(0.0,1.08,0.0)}),
 ('chest',      {'parent':'spine',    'pos':(0.0,1.31,0.0)}),
 ('neck',       {'parent':'chest',    'pos':(0.0,1.53,0.0)}),
 ('head',       {'parent':'neck',     'pos':(0.0,1.67,0.0)}),
 ('upperArm.L', {'parent':'chest',    'pos':(-0.29,1.42,0.0)}),
 ('lowerArm.L', {'parent':'upperArm.L','pos':(-0.40,1.12,0.0)}),
 ('hand.L',     {'parent':'lowerArm.L','pos':(-0.42,0.80,0.015)}),
 ('upperArm.R', {'parent':'chest',    'pos':(0.29,1.42,0.0)}),
 ('lowerArm.R', {'parent':'upperArm.R','pos':(0.40,1.12,0.0)}),
 ('hand.R',     {'parent':'lowerArm.R','pos':(0.42,0.80,0.015)}),
 ('upperLeg.L', {'parent':'hips',     'pos':(-0.135,0.69,0.0)}),
 ('lowerLeg.L', {'parent':'upperLeg.L','pos':(-0.135,0.35,0.0)}),
 ('foot.L',     {'parent':'lowerLeg.L','pos':(-0.135,0.105,0.04)}),
 ('upperLeg.R', {'parent':'hips',     'pos':(0.135,0.69,0.0)}),
 ('lowerLeg.R', {'parent':'upperLeg.R','pos':(0.135,0.35,0.0)}),
 ('foot.R',     {'parent':'lowerLeg.R','pos':(0.135,0.105,0.04)}),
])
BONE_INDEX={n:i for i,n in enumerate(BONES.keys())}
# Per-material concatenated position, normal, joint and triangle arrays.
GEOMS={k:{'p':[],'n':[],'j':[],'f':[],'count':0} for k in MATERIALS}


def add_mesh(mesh, material, bone, name=None):
    if mesh is None or len(mesh.vertices)==0 or len(mesh.faces)==0: return
    mesh=mesh.copy()
    mesh.remove_unreferenced_vertices()
    # Geometry is in character-local coordinates; assign each authored part to its nearest rig joint.
    verts=np.asarray(mesh.vertices,dtype=np.float32)
    faces=np.asarray(mesh.faces,dtype=np.int64)
    try:
        mesh.fix_normals()
        normals=np.asarray(mesh.vertex_normals,dtype=np.float32)
    except Exception:
        normals=np.zeros_like(verts); normals[:,1]=1
    normals=np.nan_to_num(normals)
    g=GEOMS[material]
    offset=g['count']
    g['p'].append(verts);g['n'].append(normals)
    joints=np.zeros((len(verts),4),dtype=np.uint16);joints[:,0]=BONE_INDEX[bone]
    weights=np.zeros((len(verts),4),dtype=np.float32);weights[:,0]=1.0
    g['j'].append(joints);g['w']=g.get('w',[]);g['w'].append(weights)
    g['f'].append(faces+offset);g['count']+=len(verts)


def ellipsoid(center, scale, material, bone, subdivisions=2, name=None):
    m=trimesh.creation.icosphere(subdivisions=subdivisions, radius=1.0)
    m.vertices*=np.asarray(scale,dtype=float)
    m.apply_translation(center)
    add_mesh(m,material,bone,name)


def box(center, extents, material, bone, rotation_y=0.0, name=None):
    m=trimesh.creation.box(extents=extents)
    if rotation_y:
        m.apply_transform(trimesh.transformations.rotation_matrix(rotation_y,[0,1,0],point=center))
    m.apply_translation(np.asarray(center)-m.centroid)
    add_mesh(m,material,bone,name)


def tapered_tube(points, radii, material, bone, sections=9, name=None):
    pts=np.asarray(points,dtype=float); rs=np.asarray(radii,dtype=float)
    verts=[];faces=[]
    prev_u=None
    for i,p in enumerate(pts):
        if i==0: tangent=pts[1]-pts[0]
        elif i==len(pts)-1: tangent=pts[-1]-pts[-2]
        else: tangent=pts[i+1]-pts[i-1]
        tangent=tangent/(np.linalg.norm(tangent)+1e-9)
        ref=np.array([0.,0.,1.])
        if abs(float(np.dot(tangent,ref)))>.88:ref=np.array([1.,0.,0.])
        u=np.cross(tangent,ref);u/=np.linalg.norm(u)+1e-9
        v=np.cross(tangent,u);v/=np.linalg.norm(v)+1e-9
        # keep the tube frame from flipping between samples
        if prev_u is not None and np.dot(u,prev_u)<0: u=-u;v=-v
        prev_u=u.copy()
        for j in range(sections):
            a=2*math.pi*j/sections
            verts.append(p+rs[i]*(math.cos(a)*u+math.sin(a)*v))
    for i in range(len(pts)-1):
        for j in range(sections):
            a=i*sections+j;b=i*sections+(j+1)%sections;c=(i+1)*sections+(j+1)%sections;d=(i+1)*sections+j
            faces.extend([[a,b,d],[b,c,d]])
    # capped ends, with a centre vertex at each end
    start_center=len(verts);verts.append(pts[0])
    end_center=len(verts);verts.append(pts[-1])
    for j in range(sections):
        faces.append([start_center,(j+1)%sections,j])
        b=(len(pts)-1)*sections+j;c=(len(pts)-1)*sections+(j+1)%sections
        faces.append([end_center,b,c])
    add_mesh(trimesh.Trimesh(vertices=np.asarray(verts),faces=np.asarray(faces),process=False),material,bone,name)


def cylinder_between(p1,p2,radius,material,bone,sections=10,radius2=None,name=None):
    a=np.asarray(p1,float);b=np.asarray(p2,float);d=b-a;length=np.linalg.norm(d)
    if length<1e-5:return
    radius2=radius if radius2 is None else radius2
    m=trimesh.creation.conical_frustum if hasattr(trimesh.creation,'conical_frustum') else None
    # Build a tapered tube with a pair of rings (axis aligned to the segment).
    tangent=d/length;ref=np.array([0.,0.,1.])
    if abs(float(np.dot(tangent,ref)))>.9:ref=np.array([1.,0.,0.])
    u=np.cross(tangent,ref);u/=np.linalg.norm(u)+1e-9;v=np.cross(tangent,u)
    verts=[]
    for center,r in [(a,radius),(b,radius2)]:
        for j in range(sections):
            ang=2*math.pi*j/sections;verts.append(center+r*(math.cos(ang)*u+math.sin(ang)*v))
    faces=[]
    for j in range(sections):
        k=(j+1)%sections;faces.extend([[j,k,sections+j],[k,sections+k,sections+j]])
    center_a=len(verts);verts.append(a.copy())
    center_b=len(verts);verts.append(b.copy())
    for j in range(sections):
        k=(j+1)%sections
        faces.append([center_a,k,j])
        faces.append([center_b,sections+j,sections+k])
    add_mesh(trimesh.Trimesh(vertices=np.asarray(verts),faces=np.asarray(faces),process=False),material,bone,name)


def torus_belt(major_r,minor_r,y,material,bone,major_sections=40,minor_sections=8,zscale=.94):
    verts=[];faces=[]
    for i in range(major_sections):
        u=2*math.pi*i/major_sections
        for j in range(minor_sections):
            v=2*math.pi*j/minor_sections
            r=major_r+minor_r*math.cos(v)
            verts.append([math.sin(u)*r,y+minor_r*math.sin(v),math.cos(u)*r*zscale])
    for i in range(major_sections):
        for j in range(minor_sections):
            a=i*minor_sections+j;b=i*minor_sections+(j+1)%minor_sections;c=((i+1)%major_sections)*minor_sections+(j+1)%minor_sections;d=((i+1)%major_sections)*minor_sections+j
            faces.extend([[a,b,d],[b,c,d]])
    add_mesh(trimesh.Trimesh(vertices=np.asarray(verts),faces=np.asarray(faces),process=False),material,bone)


def sheet(vertices,faces,material,bone):
    add_mesh(trimesh.Trimesh(vertices=np.asarray(vertices,float),faces=np.asarray(faces,int),process=False),material,bone)

# --- Core humanoid silhouette ---
# Torso and exposed athletic musculature.
ellipsoid((0,1.265,0),(.242,.365,.153),'skin','chest',3,'muscular torso')
ellipsoid((0,1.485,-.004),(.115,.145,.13),'skin','chest',2,'neck')
for s in (-1,1):
    ellipsoid((s*.112,1.405,.105),(.137,.102,.087),'skinHi','chest',3,'pectorals')
    ellipsoid((s*.085,1.26,.135),(.078,.060,.045),'skin','spine',2,'upper abs')
    ellipsoid((s*.083,1.155,.131),(.074,.055,.043),'skinHi','spine',2,'middle abs')
    ellipsoid((s*.072,1.055,.119),(.069,.050,.04),'skin','spine',2,'lower abs')
    ellipsoid((s*.187,1.20,.026),(.066,.15,.105),'skin','spine',2,'oblique')
    # clavicle, shoulder and prominent deltoid under broad sleeves
    tapered_tube([(s*.02,1.51,.085),(s*.12,1.50,.09),(s*.23,1.45,.055)], [.025,.021,.013],'skinHi','chest',7)
    ellipsoid((s*.275,1.425,.004),(.19,.19,.18),'clothFold','chest',2,'heavy robe shoulder')
    # arms beneath the sleeves, intentionally only partly visible
    cylinder_between((s*.29,1.39,0),(s*.385,1.15,.005),.112,'skin','upperArm.'+('L' if s<0 else 'R'),10,.09)
    ellipsoid((s*.355,1.27,.015),(.115,.15,.11),'skin','upperArm.'+('L' if s<0 else 'R'),2)
    cylinder_between((s*.385,1.15,.005),(s*.413,.88,.03),.083,'skin','lowerArm.'+('L' if s<0 else 'R'),10,.068)
    ellipsoid((s*.42,.775,.045),(.066,.112,.054),'skinHi','hand.'+('L' if s<0 else 'R'),2)
    # cloth sleeve volume, slouching just outside the arm
    ellipsoid((s*.335,1.285,-.008),(.18,.205,.17),'cloth','upperArm.'+('L' if s<0 else 'R'),3)
    ellipsoid((s*.385,1.12,-.005),(.145,.19,.142),'clothFold','lowerArm.'+('L' if s<0 else 'R'),3)
    ellipsoid((s*.409,.975,.008),(.118,.145,.12),'cloth','lowerArm.'+('L' if s<0 else 'R'),2)
    # linen wraps on both forearms; stacked flat oblique bands
    for j in range(6):
        y=.86+j*.038
        cylinder_between((s*.414,y,.028),(s*.414,y+.024,.028),.087,'wrap','lowerArm.'+('L' if s<0 else 'R'),9,.082)
    # hands and fingers hang below the wraps
    ellipsoid((s*.421,.744,.065),(.062,.09,.051),'skinHi','hand.'+('L' if s<0 else 'R'),2)
    for finger in range(4):
        x=s*(.386+finger*.021)
        length=[.072,.088,.082,.062][finger]
        tapered_tube([(x,.725,.085),(x+s*.004,.69,.093),(x+s*.006,.725-length,.085)], [.012,.010,.006],'skin','hand.'+('L' if s<0 else 'R'),6)
    tapered_tube([(s*.377,.772,.068),(s*.351,.735,.10),(s*.354,.70,.105)], [.018,.014,.008],'skinHi','hand.'+('L' if s<0 else 'R'),6)
    # legs with black trousers and worn boots
    hipbone='upperLeg.'+('L' if s<0 else 'R');kneebone='lowerLeg.'+('L' if s<0 else 'R');footbone='foot.'+('L' if s<0 else 'R')
    ellipsoid((s*.135,.65,-.005),(.137,.26,.135),'pants','upperLeg.'+('L' if s<0 else 'R'),3)
    cylinder_between((s*.135,.67,0),(s*.135,.355,.01),.105,'pants',hipbone,10,.087)
    ellipsoid((s*.135,.355,.012),(.095,.13,.092),'clothFold',kneebone,2)
    cylinder_between((s*.135,.37,.01),(s*.135,.14,.025),.078,'pants',kneebone,10,.075)
    ellipsoid((s*.135,.105,.015),(.105,.075,.16),'boot',footbone,2)
    ellipsoid((s*.135,.08,.102),(.112,.057,.17),'boot',footbone,2)
    # boot sole and shin folds
    box((s*.135,.043,.08),(.21,.035,.30),'leather',footbone)
    for j in range(3):
        cylinder_between((s*.135,.205+j*.045,.005),(s*.135,.224+j*.045,.005),.079,'clothFold',kneebone,9,.076)

# Bald, stern face with deep brow, ears and nose facing +Z.
ellipsoid((0,1.70,.0),(.157,.205,.151),'skinHi','head',3,'bald head')
ellipsoid((0,1.765,-.012),(.153,.145,.15),'skin','head',2,'scalp shading')
ellipsoid((0,1.615,.107),(.118,.082,.075),'skin','head',2,'jaw')
for s in (-1,1):
    ellipsoid((s*.16,1.697,.005),(.035,.065,.042),'skin','head',2,'ears')
    ellipsoid((s*.064,1.723,.135),(.045,.022,.018),'skinShadow','head',2,'eye socket')
    ellipsoid((s*.063,1.721,.151),(.027,.012,.009),'eye','head',2,'eyes')
    tapered_tube([(s*.105,1.752,.139),(s*.065,1.759,.155),(s*.024,1.751,.151)],[.022,.025,.016],'skin','head',6,'heavy brow')
    # face creases below brow
    tapered_tube([(s*.025,1.746,.156),(s*.042,1.734,.159),(s*.053,1.728,.154)],[.003,.003,.0015],'skinShadow','head',5)
# Nose bridge and nostrils.
ellipsoid((0,1.692,.161),(.029,.065,.036),'skinHi','head',2,'nose bridge')
ellipsoid((0,1.657,.18),(.033,.024,.035),'skin','head',2,'nose tip')
for s in (-1,1):ellipsoid((s*.025,1.646,.171),(.013,.009,.015),'skinShadow','head',1,'nostril')
# Grey moustache and long split goatee / tapering beard.
ellipsoid((0,1.621,.147),(.078,.031,.035),'beard','head',2,'moustache base')
for s in (-1,1):
    tapered_tube([(s*.012,1.626,.173),(s*.052,1.614,.17),(s*.09,1.607,.151),(s*.112,1.614,.135)],[.027,.022,.014,.003],'beardHi','head',8,'moustache sweep')
# Main beard body flowing to chest; multiple tapered locks give a sculpted silhouette.
tapered_tube([(0,1.61,.125),(0,1.56,.14),(-.008,1.48,.16),(.005,1.40,.166),(-.018,1.32,.15),(-.012,1.23,.125),(.008,1.16,.10)],[.075,.082,.074,.061,.047,.027,.002],'beard','head',12,'long grey beard')
for i in range(7):
    x=(i-3)*.018
    startY=1.57-random.random()*.04
    endY=1.18+random.random()*.12
    z=.181-abs(x)*.16
    bend=random.uniform(-.022,.022)
    tapered_tube([(x*.45,startY,z),(x*.75,1.47+random.uniform(-.02,.025),z+.009),(x+bend,1.34+random.uniform(-.025,.02),z-.006),(x+bend*.4,endY,z-.028)],[random.uniform(.014,.023),.018,.010,.0015],'beardHi' if i%3==0 else 'beard','head',6,'beard lock')
# Scarf/cowl framing neck, with the top of scalp left bare.
ellipsoid((0,1.515,-.05),(.205,.12,.165),'clothFold','chest',3,'raised rear cowl')

# Main long open-front cloak: a draped, uneven hem with broken points and folds.
verts=[];faces=[];rows=18;cols=42;amin=.67;amax=2*math.pi-.67
for r in range(rows):
    t=r/(rows-1)
    ybase=1.51-(1.39*t)
    for c in range(cols):
        u=c/(cols-1);ang=amin+(amax-amin)*u
        wrinkle=(math.sin(ang*7+t*10)*.018+math.sin(ang*13-t*4)*.009)*(0.3+t)
        rx=.275+.205*t+wrinkle
        rz=.205+.115*t+wrinkle*.65
        hem=0
        if r==rows-1:
            hem=-(.035*(.5+.5*math.sin(ang*17))+(.09 if int(c)%7==0 else 0)+.025*math.sin(ang*31))
        x=math.sin(ang)*rx + math.sin(t*5+ang*9)*.012
        z=math.cos(ang)*rz + math.sin(ang*6+t*11)*.009
        y=ybase+hem + math.sin(ang*9+t*5)*.018*t
        verts.append([x,y,z])
for r in range(rows-1):
    for c in range(cols-1):
        a=r*cols+c;b=a+1;d=(r+1)*cols+c;cc=d+1
        faces.extend([[a,b,d],[b,cc,d]])
sheet(verts,faces,'cloth','hips')
# Additional offset folds on the back of the cloak add deep sculptural striations.
for k in range(9):
    ang=math.pi+(-.82+k*.205)
    pts=[];rads=[]
    for i in range(5):
        t=i/4;y=1.39-1.25*t
        rad=.29+.195*t+.012*math.sin(i*1.7+k)
        pts.append([math.sin(ang)*rad,y,math.cos(ang)*(.22+.11*t)-.012])
        rads.append(.009 if i not in (1,2) else .015)
    tapered_tube(pts,rads,'clothFold','hips',6,'cloak fold piping')
# Ragged fluttering cape tails behind left and right, triangulated cloth strips.
for s in (-1,1):
    v=[(s*.18,1.48,-.12),(s*.36,1.40,-.15),(s*.48,.95,-.22),(s*.61,.42,-.32),(s*.54,.15,-.31),(s*.42,.34,-.28),(s*.36,.12,-.31),(s*.29,.50,-.23),(s*.22,.86,-.18)]
    f=[[0,1,8],[1,2,8],[2,7,8],[2,3,7],[3,5,6],[3,4,5],[2,5,3]]
    sheet(v,f,'clothFold' if s<0 else 'cloth','hips')
# Open robe lapels: narrow heavy panels flanking chest, not covering the abs.
for s in (-1,1):
    v=[(s*.18,1.55,.17),(s*.285,1.47,.14),(s*.31,1.18,.19),(s*.245,.92,.235),(s*.175,.98,.19),(s*.20,1.25,.18)]
    f=[[0,1,5],[1,2,5],[2,3,4],[2,4,5]]
    sheet(v,f,'clothFold','chest')
    # Torn strips along the lower skirt edges.
    for j in range(3):
        x=s*(.34+.055*j)
        y=.43-j*.05
        tapered_tube([(x,y+.17,-.05),(x+s*.015,y+.07,-.10),(x+s*random.uniform(-.02,.02),y-.06,-.14)],[.025,.018,.001],'cloth','hips',6,'frayed robe strip')

# Under-robe trousers panel and overlapping wrap skirt layers.
ellipsoid((0,.78,-.012),(.255,.19,.22),'pants','hips',3,'waist trousers')
# Waist sash as a woven diagonal belt wrapping the body.
torus_belt(.265,.037,.895,'leather','hips',48,8,1.0)
# Secondary sash, angled strap crossing waist.
tapered_tube([(-.265,.94,.04),(-.16,.90,.22),(0,.875,.278),(.18,.91,.22),(.27,.94,.04)],[.035,.032,.029,.032,.025],'wrap','hips',8,'linen waist sash')
# Belt buckle, loop, rivets and small key-like hanging charms.
box((0,.895,.294),(.105,.098,.035),'metal','hips')
box((0,.895,.315),(.055,.054,.013),'leather','hips')
for s in (-1,1):
    for j in range(3):ellipsoid((s*(.13+j*.037),.895,.24-j*.018),(.012,.012,.009),'metal','hips',1,'belt rivet')
# Hanging belt tails.
sheet([(-.19,.88,.26),(-.11,.86,.30),(-.18,.46,.31),(-.25,.40,.29),(-.22,.65,.28)],[[0,1,2],[0,2,4],[2,3,4]],'wrap','hips')
sheet([(0,.87,.32),(.08,.87,.31),(.13,.29,.31),(.07,.26,.32),(.02,.52,.33)],[[0,1,2],[0,2,4],[2,3,4]],'leather','hips')
# Rings, keys and weathered medallions on the left hip.
for i in range(3):
    x=-.20-i*.035;y=.78-i*.13;z=.27-i*.012
    # oval charm loops oriented in the character's front plane
    pts=[]
    for j in range(17):
        a=2*math.pi*j/16;pts.append([x+.036*math.cos(a),y+.052*math.sin(a),z])
    tapered_tube(pts,[.009]*len(pts),'metal','hips',5,'belt charm ring')
ellipsoid((-.27,.52,.255),(.044,.055,.018),'metal','hips',2,'old coin pendant')
ellipsoid((-.27,.52,.275),(.027,.036,.009),'leather','hips',2,'coin engraving')
# small dangling weathered key
cylinder_between((-.13,.70,.30),(-.13,.52,.32),.012,'metal','hips',8,.009)
torus_belt(.026,.008,.49,'metal','hips',16,5,1)

# Shoulder seams / studded worn robe details.
for s in (-1,1):
    for j in range(4):
        ellipsoid((s*(.27+j*.018),1.49-j*.035,.103-j*.018),(.011,.012,.008),'leather','chest',1,'robe stitch')

# Geometry/material mapping and skin rig.
# Keep only used materials in the output, in palette order.
used=[k for k,v in GEOMS.items() if v['count']>0]
mat_index={name:i for i,name in enumerate(used)}

# Binary buffer builder with aligned bufferViews/accessors.
buf=bytearray();bufferViews=[];accessors=[]
def align4():
    while len(buf)%4:buf.append(0)
def add_view(data,target=None):
    align4();offset=len(buf);raw=bytes(data);buf.extend(raw)
    view={'buffer':0,'byteOffset':offset,'byteLength':len(raw)}
    if target:view['target']=target
    bufferViews.append(view);return len(bufferViews)-1
def add_accessor(data,component_type,type_name,count,target=None,minv=None,maxv=None,normalized=False):
    arr=np.asarray(data)
    view=add_view(arr.tobytes(order='C'),target)
    acc={'bufferView':view,'componentType':component_type,'count':int(count),'type':type_name}
    if minv is not None:acc['min']=[float(x) for x in minv]
    if maxv is not None:acc['max']=[float(x) for x in maxv]
    if normalized:acc['normalized']=True
    accessors.append(acc);return len(accessors)-1

primitives=[]
for material in used:
    g=GEOMS[material]
    P=np.concatenate(g['p'],axis=0).astype(np.float32);N=np.concatenate(g['n'],axis=0).astype(np.float32)
    J=np.concatenate(g['j'],axis=0).astype(np.uint16);W=np.concatenate(g['w'],axis=0).astype(np.float32)
    F=np.concatenate(g['f'],axis=0).astype(np.uint32)
    # Re-normalise smooth normals in case adjoining source parts changed vertex attributes.
    lens=np.linalg.norm(N,axis=1);lens[lens<1e-7]=1;N=N/lens[:,None]
    # GLTF index buffer must fit in uint16 for broad mobile compatibility; one primitive per material.
    if len(P)>65535: raise ValueError(f'material {material} too many vertices: {len(P)}')
    posAcc=add_accessor(P,5126,'VEC3',len(P),34962,P.min(axis=0),P.max(axis=0))
    norAcc=add_accessor(N,5126,'VEC3',len(N),34962)
    jointAcc=add_accessor(J,5123,'VEC4',len(J),34962)
    weightAcc=add_accessor(W,5126,'VEC4',len(W),34962)
    idxAcc=add_accessor(F.astype(np.uint16).reshape(-1),5123,'SCALAR',F.size,34963,[int(F.min())],[int(F.max())])
    primitives.append({'attributes':{'POSITION':posAcc,'NORMAL':norAcc,'JOINTS_0':jointAcc,'WEIGHTS_0':weightAcc},'indices':idxAcc,'material':mat_index[material],'mode':4})

# Build joint nodes, with glTF local translations calculated from parent global rest positions.
node_index={name:i+2 for i,name in enumerate(BONES.keys())} # 0=root, 1=skinned mesh
nodes=[{'name':'AshenWarden_Root','children':[1,node_index['hips']]},{'name':'AshenWarden_SkinnedMesh','mesh':0,'skin':0}]
children_by_parent={n:[] for n in [None]+list(BONES.keys())}
for name,b in BONES.items():children_by_parent[b['parent']].append(name)
for name,b in BONES.items():
    pos=np.asarray(b['pos'],float);parent=b['parent']
    if parent is not None:pos-=np.asarray(BONES[parent]['pos'],float)
    node={'name':name,'translation':[float(x) for x in pos]}
    if children_by_parent[name]:node['children']=[node_index[ch] for ch in children_by_parent[name]]
    nodes.append(node)
# Inverse bind matrices use each joint's model-space rest origin; matrix data column-major.
ibms=[]
for name,b in BONES.items():
    T=np.eye(4,dtype=float);T[:3,3]=np.asarray(b['pos'],float)
    inv=np.linalg.inv(T)
    ibms.extend(inv.flatten(order='F').tolist())
ibmAcc=add_accessor(np.asarray(ibms,dtype=np.float32),5126,'MAT4',len(BONES))

# Material animation helpers.
def quat_axis(axis,angle):
    ax=np.asarray(axis,float);ax=ax/(np.linalg.norm(ax)+1e-9);s=math.sin(angle/2)
    return [float(ax[0]*s),float(ax[1]*s),float(ax[2]*s),float(math.cos(angle/2))]

def build_animation(name,duration,values):
    # values maps bone -> {channel: list[(time, quaternion or translation)]}
    samplers=[];channels=[]
    for bone,tracks in values.items():
        for path,keys in tracks.items():
            times=np.asarray([k[0] for k in keys],dtype=np.float32)
            data=np.asarray([k[1] for k in keys],dtype=np.float32)
            if path=='rotation': type_name='VEC4'
            elif path=='translation':type_name='VEC3'
            else:continue
            inputAcc=add_accessor(times,5126,'SCALAR',len(times),minv=[float(times.min())],maxv=[float(times.max())])
            outputAcc=add_accessor(data,5126,type_name,len(data))
            si=len(samplers);samplers.append({'input':inputAcc,'output':outputAcc,'interpolation':'LINEAR'})
            channels.append({'sampler':si,'target':{'node':node_index[bone],'path':path}})
    return {'name':name,'samplers':samplers,'channels':channels}

def rot_track(angles,axis=(1,0,0),duration=1.0):
    # angles evenly spaced around duration; preserve seamless loop when possible.
    return [(duration*i/(len(angles)-1),quat_axis(axis,a)) for i,a in enumerate(angles)]

animations=[]
animations.append(build_animation('Idle',2.0,{
 'chest':{'rotation':rot_track([-.012,.018,-.012],duration=2.0)},
 'head':{'rotation':rot_track([0,.012,0],duration=2.0)},
 'upperArm.L':{'rotation':rot_track([-.018,.012,-.018],duration=2.0)},
 'upperArm.R':{'rotation':rot_track([.018,-.012,.018],duration=2.0)},
}))
animations.append(build_animation('Walk',1.0,{
 'upperLeg.L':{'rotation':rot_track([-.48,0,.48,0,-.48],duration=1.0)},
 'upperLeg.R':{'rotation':rot_track([.48,0,-.48,0,.48],duration=1.0)},
 'lowerLeg.L':{'rotation':rot_track([.06,.28,.04,.12,.06],duration=1.0)},
 'lowerLeg.R':{'rotation':rot_track([.04,.12,.06,.28,.04],duration=1.0)},
 'upperArm.L':{'rotation':rot_track([.28,0,-.28,0,.28],duration=1.0)},
 'upperArm.R':{'rotation':rot_track([-.28,0,.28,0,-.28],duration=1.0)},
 'lowerArm.L':{'rotation':rot_track([-.05,-.12,-.03,-.12,-.05],duration=1.0)},
 'lowerArm.R':{'rotation':rot_track([-.03,-.12,-.05,-.12,-.03],duration=1.0)},
 'chest':{'rotation':rot_track([-.025,.025,-.025],duration=1.0)},
}))
animations.append(build_animation('Run',.72,{
 'upperLeg.L':{'rotation':rot_track([-.78,0,.78,0,-.78],duration=.72)},
 'upperLeg.R':{'rotation':rot_track([.78,0,-.78,0,.78],duration=.72)},
 'lowerLeg.L':{'rotation':rot_track([.10,.72,.12,.25,.10],duration=.72)},
 'lowerLeg.R':{'rotation':rot_track([.12,.25,.10,.72,.12],duration=.72)},
 'upperArm.L':{'rotation':rot_track([.54,0,-.54,0,.54],duration=.72)},
 'upperArm.R':{'rotation':rot_track([-.54,0,.54,0,-.54],duration=.72)},
 'lowerArm.L':{'rotation':rot_track([-.16,-.28,-.08,-.28,-.16],duration=.72)},
 'lowerArm.R':{'rotation':rot_track([-.08,-.28,-.16,-.28,-.08],duration=.72)},
 'chest':{'rotation':rot_track([-.06,.03,-.06],duration=.72)},
}))
animations.append(build_animation('Jump',.9,{
 'upperLeg.L':{'rotation':rot_track([0,-.42,-.56,-.12,0],duration=.9)},
 'upperLeg.R':{'rotation':rot_track([0,-.42,-.56,-.12,0],duration=.9)},
 'lowerLeg.L':{'rotation':rot_track([0,.22,.36,.06,0],duration=.9)},
 'lowerLeg.R':{'rotation':rot_track([0,.22,.36,.06,0],duration=.9)},
 'upperArm.L':{'rotation':rot_track([0,-.65,-.76,-.12,0],duration=.9)},
 'upperArm.R':{'rotation':rot_track([0,-.65,-.76,-.12,0],duration=.9)},
 'chest':{'rotation':rot_track([0,-.10,-.04,0],duration=.9)},
}))
animations.append(build_animation('Attack',.72,{
 'upperArm.R':{'rotation':rot_track([0,-.65,-1.28,.38,0],duration=.72)},
 'lowerArm.R':{'rotation':rot_track([0,-.55,-.12,.15,0],duration=.72)},
 'chest':{'rotation':rot_track([0,-.15,.16,0],axis=(0,1,0),duration=.72)},
}))
animations.append(build_animation('KnockDown',1.05,{
 'spine':{'rotation':rot_track([0,.3,1.05,1.12,1.12],duration=1.05)},
 'chest':{'rotation':rot_track([0,.1,.58,.65,.65],duration=1.05)},
 'upperArm.L':{'rotation':rot_track([0,-.3,-.8,-.8,-.8],duration=1.05)},
 'upperArm.R':{'rotation':rot_track([0,-.3,.8,.8,.8],duration=1.05)},
 'upperLeg.L':{'rotation':rot_track([0,.1,.45,.5,.5],duration=1.05)},
 'upperLeg.R':{'rotation':rot_track([0,-.1,-.35,-.4,-.4],duration=1.05)},
}))
animations.append(build_animation('GetUp',.95,{
 'spine':{'rotation':rot_track([1.05,.8,.35,0],duration=.95)},
 'chest':{'rotation':rot_track([.65,.32,.1,0],duration=.95)},
 'upperArm.L':{'rotation':rot_track([-.8,-.5,-.2,0],duration=.95)},
 'upperArm.R':{'rotation':rot_track([.8,.5,.2,0],duration=.95)},
 'upperLeg.L':{'rotation':rot_track([.5,.3,.1,0],duration=.95)},
 'upperLeg.R':{'rotation':rot_track([-.4,-.25,-.08,0],duration=.95)},
}))

# Build glTF JSON and binary GLB container.
# Every character part is rigid-weighted to one humanoid bone; skeleton channels provide gameplay locomotion.
materials=[]
for name in used:
    mat=MATERIALS[name]
    rgba=mat['color'];base=[c/255 for c in rgba[:3]]+[rgba[3]/255]
    materials.append({'name':mat['name'],'pbrMetallicRoughness':{'baseColorFactor':base,'metallicFactor':mat['metallic'],'roughnessFactor':mat['roughness']},'doubleSided':name in ('cloth','clothFold','pants','wrap','beard','beardHi')})

json_doc={
 'asset':{'version':'2.0','generator':'OpenAI procedural Ashen Warden character builder'},
 'scene':0,'scenes':[{'name':'Ashen Warden','nodes':[0]}],
 'nodes':nodes,
 'meshes':[{'name':'AshenWarden_Geometry','primitives':primitives}],
 'skins':[{'name':'AshenWarden_HumanoidRig','inverseBindMatrices':ibmAcc,'skeleton':node_index['hips'],'joints':[node_index[n] for n in BONES.keys()]}],
 'materials':materials,'animations':animations,
 'buffers':[{'byteLength':0}], 'bufferViews':bufferViews,'accessors':accessors,
}
# align the end of BIN chunk. buffer byteLength excludes GLB padding if present; the JSON buffer length must be the full binary data length.
align4();json_doc['buffers'][0]['byteLength']=len(buf)
json_bytes=json.dumps(json_doc,separators=(',',':'),ensure_ascii=False).encode('utf-8')
while len(json_bytes)%4:json_bytes+=b' '
while len(buf)%4:buf.append(0)
total=12+8+len(json_bytes)+8+len(buf)
with open(OUT,'wb') as f:
    f.write(struct.pack('<III',0x46546C67,2,total))
    f.write(struct.pack('<II',len(json_bytes),0x4E4F534A));f.write(json_bytes)
    f.write(struct.pack('<II',len(buf),0x004E4942));f.write(buf)

# Re-open the artifact with trimesh as a structural sanity check.
scene=trimesh.load(OUT,force='scene')
all_vertices=[];all_faces=0
for geom in scene.geometry.values():
    all_vertices.append(np.asarray(geom.vertices));all_faces+=len(geom.faces)
verts=np.vstack(all_vertices) if all_vertices else np.zeros((0,3))
bounds=np.array([verts.min(axis=0),verts.max(axis=0)]) if len(verts) else None
print(json.dumps({'file':OUT,'bytes':os.path.getsize(OUT),'materialCount':len(materials),'primitiveCount':len(primitives),'boneCount':len(BONES),'animationNames':[a['name'] for a in animations],'vertexCount':int(len(verts)),'triangleCount':int(all_faces),'bounds':bounds.tolist() if bounds is not None else None},indent=2))
